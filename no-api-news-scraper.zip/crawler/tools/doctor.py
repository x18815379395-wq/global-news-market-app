import sys, time, yaml, json
import feedparser
from pathlib import Path

def load_yaml(p): 
    return yaml.safe_load(Path(p).read_text(encoding="utf-8"))

def check_rss(name, feeds, sample=3):
    ok=True; msgs=[]
    for url in feeds:
        try:
            feed = feedparser.parse(url)
            n = min(sample, len(feed.entries))
            msgs.append(f"{name} feed ok: {url} (entries={len(feed.entries)})")
            ok = ok and (n > 0)
        except Exception as e:
            msgs.append(f"{name} feed FAIL: {url} -> {e}")
            ok=False
    return ok, msgs

def check_truth(handle, selectors, playwright_cfg, sample=3):
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            b = getattr(p, playwright_cfg["browser"]).launch(headless=playwright_cfg["headless"])
            ctx = b.new_context()
            page = ctx.new_page()
            page.goto(f"https://truthsocial.com/@{handle}", wait_until="domcontentloaded", timeout=30000)
            time.sleep(playwright_cfg["wait_after_load_sec"])
            cards = page.locator(selectors["article"]).all()[:sample]
            ok = len(cards) > 0
            ctx.close(); b.close()
        return ok, [f"Truth @{handle} cards={len(cards)}"]
    except Exception as e:
        return False, [f"Truth @{handle} FAIL -> {e}"]

def check_x(handle, selectors, playwright_cfg, sample=3):
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            b = getattr(p, playwright_cfg["browser"]).launch(headless=playwright_cfg["headless"])
            ctx = b.new_context()
            page = ctx.new_page()
            page.goto(f"https://x.com/{handle}", wait_until="domcontentloaded", timeout=30000)
            time.sleep(playwright_cfg["wait_after_load_sec"])
            cards = page.locator(selectors["article"]).all()[:sample]
            ok = len(cards) > 0
            ctx.close(); b.close()
        return ok, [f"X @{handle} cards={len(cards)}"]
    except Exception as e:
        return False, [f"X @{handle} FAIL -> {e}"]

def main():
    cfg = load_yaml("config/crawler.yaml")
    selectors = load_yaml("config/selectors.yaml")
    report = {"DeepSeek configured": True}

    rss_status = {}
    rss_msgs = []
    for name, node in cfg["crawler"]["rss"].items():
        if node.get("enabled") and node.get("feeds"):
            ok, msgs = check_rss(name, node["feeds"], cfg["healthcheck"]["rss_sample_limit"])
            rss_status["Financial Times" if name=="FinancialTimes" else name] = ok
            rss_msgs.extend(msgs)
        else:
            rss_status["Financial Times" if name=="FinancialTimes" else name] = False
            rss_msgs.append(f"{name} disabled or no feeds configured")
    report["RSS sources"] = rss_status

    # Truth
    ts_cfg = cfg["crawler"]["social"]["TruthSocial"]
    ts_ok_all = True; ts_msgs=[]
    if ts_cfg.get("enabled"):
        for h in ts_cfg.get("handles", []):
            ok, msgs = check_truth(h, selectors["truth"], cfg["playwright"], cfg["healthcheck"]["truth_sample_limit"])
            ts_ok_all = ts_ok_all and ok
            ts_msgs.extend(msgs)
    report["Truth Social"] = {"realDonaldTrump": ts_ok_all}

    # X
    x_cfg = cfg["crawler"]["social"]["X"]
    x_ok_all = True; x_msgs=[]
    if x_cfg.get("enabled"):
        for h in x_cfg.get("handles", []):
            ok, msgs = check_x(h, selectors["x"], cfg["playwright"], cfg["healthcheck"]["x_sample_limit"])
            x_ok_all = x_ok_all and ok
            x_msgs.extend(msgs)
    report["Twitter scraper ready"] = x_ok_all

    print("API Status Check:")
    print(f"  DeepSeek configured: {report['DeepSeek configured']}")
    print(f"  RSS sources: {report['RSS sources']}")
    print(f"  Truth Social: {{'realDonaldTrump': {ts_ok_all}}}")
    print(f"  Twitter scraper ready: {x_ok_all}")
    print("\nDetails:")
    for m in rss_msgs + ts_msgs + x_msgs:
        print("  -", m)

if __name__ == "__main__":
    main()
