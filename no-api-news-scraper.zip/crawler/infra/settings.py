import yaml, pathlib

def load_yaml(path: str):
    p = pathlib.Path(path)
    with p.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)
